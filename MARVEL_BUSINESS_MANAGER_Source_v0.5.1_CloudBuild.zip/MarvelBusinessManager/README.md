# MARVEL Business Manager

Offline-first Android business manager. Business records and transactions are stored locally in SQLite on the device. No account or internet connection is required for core use.

## Current project version: 0.5.0 (source milestone)

### Included in the source
- Create and manage separate businesses.
- Record sales and expenses per business.
- Add products with opening stock, cost price, selling price and a configurable low-stock threshold.
- View each business inventory and low-stock warnings.
- Adjust stock for deliveries, damage or corrections; stock cannot be reduced below zero.
- Record product sales using the product selling price. The sale transaction, stock deduction and stock movement are saved atomically.
- Naira currency presentation.
- Business reports: lifetime sales, expenses and net cash result; rolling 30-day summaries; inventory cost/retail valuation; potential margin on current stock; and low-stock count.
- Save a full local SQLite backup to a user-selected location through Android's document picker.
- Restore a MARVEL database backup after an integrity and required-table check. Restore replaces the current app data, with an in-app warning first.
- Export businesses, products, transactions and stock movements into one CSV file using Android's document picker. Text cells are quoted and formula-leading text is neutralized.

### Backup and restore notes
- Backup files contain the app's local business database. Store them somewhere safe; anyone with the file may be able to inspect its contents.
- Restore is destructive to the current local database. Save a current backup before restoring.
- The restore flow checks SQLite integrity, required tables and supported database version before replacing the active database.
- CSV is for viewing/analysis and is not a restorable backup. Use the `.mbak` database backup for restore.

### Build
Open this folder in Android Studio with Android SDK 35 installed, then sync Gradle and build the `app` debug variant. The project currently does not include a Gradle wrapper. This source update has not yet been compiled into an APK or device-tested.

### Build an APK using a phone (GitHub Actions)
A separate cloud-build workflow file is supplied as `MARVEL_BUSINESS_MANAGER_android-apk.yml` alongside this source archive. To use it without Android Studio:
1. Sign in at https://github.com and create an empty repository named `MarvelBusinessManager`.
2. Upload this source archive, `MARVEL_BUSINESS_MANAGER_Source_v0.5.1_CloudBuild.zip`, to the repository root and commit it to `main`.
3. In GitHub choose **Add file → Create new file**. Name the file `.github/workflows/android-apk.yml`.
4. Copy the complete contents of the supplied `MARVEL_BUSINESS_MANAGER_android-apk.yml` into the new file and commit it to `main`.
5. Open **Actions**. Wait for **Build MARVEL Business Manager APK** to finish with a green check.
6. Open the successful run and download `MARVEL-Business-Manager-debug-APK`. Extract it; the installable file is `app-debug.apk`.

Only install an APK from your own successful workflow run. A successful cloud build proves compilation, not full testing on the TECNO POP 10 Pro. The first installation and on-phone verification remain separate steps.
### Data and migration
Database version 2 adds a low-stock threshold column to the existing products table. The upgrade is additive and preserves existing business, sales, expense and stock data. Version 0.5.0 does not change the database schema.

### Reporting notes
The report labels sales minus recorded expenses as a **net cash result**, not accounting profit. Product purchase costs are not automatically posted as expenses. Inventory valuation is current quantity multiplied by recorded unit cost or selling price. The 30-day period is a rolling 30×24-hour window.
