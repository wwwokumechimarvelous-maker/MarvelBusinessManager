package com.marvelokstudios.businessmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/** Local-only database. No account or internet connection is required. */
public final class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "marvel_business_manager.db";
    private static final int DB_VERSION = 2;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE businesses (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "business_type TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', " +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, " +
                "name TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, cost_price REAL NOT NULL DEFAULT 0, " +
                "selling_price REAL NOT NULL DEFAULT 0, low_stock_threshold REAL NOT NULL DEFAULT 5, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, " +
                "type TEXT NOT NULL CHECK(type IN ('SALE','EXPENSE')), amount REAL NOT NULL, " +
                "note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, " +
                "FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE stock_movements (id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, " +
                "change_amount REAL NOT NULL, reason TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, " +
                "FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_products_business ON products(business_id)");
        db.execSQL("CREATE INDEX idx_transactions_business_date ON transactions(business_id, created_at)");
        db.execSQL("CREATE INDEX idx_stock_product_date ON stock_movements(product_id, created_at)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 already had products and stock_movements; add the alert threshold safely.
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE products ADD COLUMN low_stock_threshold REAL NOT NULL DEFAULT 5");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_products_business ON products(business_id)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_stock_product_date ON stock_movements(product_id, created_at)");
        }
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    public long addBusiness(String name, String type, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name.trim()); values.put("business_type", type.trim());
        values.put("phone", phone.trim()); values.put("created_at", System.currentTimeMillis());
        return db.insert("businesses", null, values);
    }

    public Cursor getBusinesses() {
        return getReadableDatabase().query("businesses",
                new String[]{"id", "name", "business_type", "phone"}, null, null, null, null, "name COLLATE NOCASE ASC");
    }

    public int getBusinessCount() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM businesses", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }



    public long addProduct(long businessId, String name, double quantity, double costPrice,
                           double sellingPrice, double lowStockThreshold) {
        if (name == null || name.trim().isEmpty() || quantity < 0 || costPrice < 0 ||
                sellingPrice < 0 || lowStockThreshold < 0) return -1L;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("business_id", businessId); values.put("name", name.trim());
            values.put("quantity", quantity); values.put("cost_price", costPrice);
            values.put("selling_price", sellingPrice); values.put("low_stock_threshold", lowStockThreshold);
            long id = db.insert("products", null, values);
            if (id > 0 && quantity > 0) {
                ContentValues movement = new ContentValues(); movement.put("product_id", id);
                movement.put("change_amount", quantity); movement.put("reason", "Opening stock");
                movement.put("created_at", System.currentTimeMillis()); db.insert("stock_movements", null, movement);
            }
            if (id > 0) db.setTransactionSuccessful();
            return id;
        } finally { db.endTransaction(); }
    }

    public Cursor getProducts(long businessId) {
        return getReadableDatabase().query("products",
                new String[]{"id", "name", "quantity", "cost_price", "selling_price", "low_stock_threshold"},
                "business_id=?", new String[]{String.valueOf(businessId)}, null, null, "name COLLATE NOCASE ASC");
    }

    public int getLowStockCount(long businessId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM products WHERE business_id=? AND quantity<=low_stock_threshold",
                new String[]{String.valueOf(businessId)})) { return c.moveToFirst() ? c.getInt(0) : 0; }
    }

    public boolean adjustStock(long productId, double change, String reason) {
        if (change == 0d) return false;
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            int updated;

            try (Cursor c = db.rawQuery("SELECT quantity FROM products WHERE id=?", new String[]{String.valueOf(productId)})) {
                if (!c.moveToFirst() || c.getDouble(0) + change < 0) return false;
            }
            android.database.sqlite.SQLiteStatement st = db.compileStatement(
                    "UPDATE products SET quantity=quantity+? WHERE id=? AND quantity+?>=0");
            st.bindDouble(1, change); st.bindLong(2, productId); st.bindDouble(3, change);
            updated = st.executeUpdateDelete();
            if (updated != 1) return false;
            ContentValues movement = new ContentValues(); movement.put("product_id", productId);
            movement.put("change_amount", change); movement.put("reason", reason == null ? "Stock adjustment" : reason.trim());
            movement.put("created_at", System.currentTimeMillis());
            if (db.insert("stock_movements", null, movement) < 0) return false;
            db.setTransactionSuccessful(); return true;
        } finally { db.endTransaction(); }
    }

    /** Records a product sale and reduces stock atomically; failed sales leave both unchanged. */
    public boolean sellProduct(long businessId, long productId, double quantity) {
        if (quantity <= 0) return false;
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            String productName; double price;
            try (Cursor c = db.rawQuery("SELECT name,selling_price,quantity FROM products WHERE id=? AND business_id=?",
                    new String[]{String.valueOf(productId), String.valueOf(businessId)})) {
                if (!c.moveToFirst() || c.getDouble(2) < quantity) return false;
                productName = c.getString(0); price = c.getDouble(1);
            }
            double total = price * quantity;
            if (total <= 0) return false;
            ContentValues sale = new ContentValues(); sale.put("business_id", businessId);
            sale.put("type", "SALE"); sale.put("amount", total);
            sale.put("note", "Product sale: " + productName + " x " + quantity);
            sale.put("created_at", System.currentTimeMillis());
            if (db.insert("transactions", null, sale) < 0) return false;
            android.database.sqlite.SQLiteStatement st = db.compileStatement(
                    "UPDATE products SET quantity=quantity-? WHERE id=? AND business_id=? AND quantity>=?");
            st.bindDouble(1, quantity); st.bindLong(2, productId); st.bindLong(3, businessId); st.bindDouble(4, quantity);
            if (st.executeUpdateDelete() != 1) return false;
            ContentValues movement = new ContentValues(); movement.put("product_id", productId);
            movement.put("change_amount", -quantity); movement.put("reason", "Sale");
            movement.put("created_at", System.currentTimeMillis());
            if (db.insert("stock_movements", null, movement) < 0) return false;
            db.setTransactionSuccessful(); return true;
        } finally { db.endTransaction(); }
    }

    public long addTransaction(long businessId, String type, double amount, String note) {
        if (amount <= 0d || !("SALE".equals(type) || "EXPENSE".equals(type))) return -1L;
        ContentValues values = new ContentValues();
        values.put("business_id", businessId);
        values.put("type", type);
        values.put("amount", amount);
        values.put("note", note == null ? "" : note.trim());
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("transactions", null, values);
    }

    public double getBusinessTotal(long businessId, String type) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE business_id=? AND type=?",
                new String[]{String.valueOf(businessId), type})) {
            return c.moveToFirst() ? c.getDouble(0) : 0d;
        }
    }


    public double getBusinessTotalSince(long businessId, String type, long sinceMillis) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE business_id=? AND type=? AND created_at>=?",
                new String[]{String.valueOf(businessId), type, String.valueOf(sinceMillis)})) {
            return c.moveToFirst() ? c.getDouble(0) : 0d;
        }
    }

    public double getInventoryCostValue(long businessId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(quantity*cost_price),0) FROM products WHERE business_id=?",
                new String[]{String.valueOf(businessId)})) {
            return c.moveToFirst() ? c.getDouble(0) : 0d;
        }
    }

    public double getInventorySellingValue(long businessId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(quantity*selling_price),0) FROM products WHERE business_id=?",
                new String[]{String.valueOf(businessId)})) {
            return c.moveToFirst() ? c.getDouble(0) : 0d;
        }
    }

    public int getProductCount(long businessId) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM products WHERE business_id=?",
                new String[]{String.valueOf(businessId)})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public double getTotalSales() { return sumTransactions("SALE"); }
    public double getTotalExpenses() { return sumTransactions("EXPENSE"); }

    private double sumTransactions(String type) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=?", new String[]{type})) {
            return c.moveToFirst() ? c.getDouble(0) : 0d;
        }
    }
}
