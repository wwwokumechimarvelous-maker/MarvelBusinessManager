package com.marvelokstudios.businessmanager;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.app.AlertDialog;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.NumberFormat;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(16, 26, 43);
    private static final int GOLD = Color.rgb(216, 173, 85);
    private static final int BG = Color.rgb(245, 247, 250);
    private static final int REQUEST_BACKUP = 7101;
    private static final int REQUEST_RESTORE = 7102;
    private static final int REQUEST_CSV = 7103;
    private DatabaseHelper database;
    private LinearLayout content;
    private final NumberFormat naira = NumberFormat.getCurrencyInstance(new Locale("en", "NG"));

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        database = new DatabaseHelper(this);
        naira.setMaximumFractionDigits(2);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(content); setContentView(scroll);

        TextView brand = text("MARVEL", 13, GOLD, true); brand.setLetterSpacing(.22f); content.addView(brand);
        TextView title = text("Business Manager", 27, Color.WHITE, true);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(18), dp(18), dp(18), dp(20)); header.setBackgroundColor(NAVY);
        header.addView(title); TextView subtitle = text("Your business. Your numbers. In your control.", 13, Color.LTGRAY, false); subtitle.setPadding(0, dp(5), 0, 0); header.addView(subtitle);
        content.addView(header, params(-1, -2));

        section("OVERVIEW");
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("BUSINESSES", String.valueOf(database.getBusinessCount())), new LinearLayout.LayoutParams(0, dp(88), 1));
        View gap = new View(this); stats.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        stats.addView(statCard("TOTAL SALES", naira.format(database.getTotalSales())), new LinearLayout.LayoutParams(0, dp(88), 1));
        content.addView(stats);
        TextView expenses = text("Recorded expenses: " + naira.format(database.getTotalExpenses()), 14, NAVY, true); expenses.setPadding(0, dp(12), 0, dp(8)); content.addView(expenses);

        section("YOUR BUSINESSES");
        Button add = button("+  ADD A BUSINESS"); add.setOnClickListener(v -> showAddBusiness()); content.addView(add, params(-1, dp(50)));
        Cursor cursor = database.getBusinesses();
        try {
            if (cursor.getCount() == 0) {
                TextView empty = text("No businesses added yet. Add your first business to get started.", 14, Color.DKGRAY, false);
                empty.setPadding(dp(4), dp(18), dp(4), dp(10)); content.addView(empty);
            } else while (cursor.moveToNext()) {
                long businessId = cursor.getLong(0);
                String name = cursor.getString(1), type = cursor.getString(2), phone = cursor.getString(3);
                LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15), dp(13), dp(15), dp(13)); card.setBackgroundColor(Color.WHITE);
                TextView n = text(name, 17, NAVY, true); card.addView(n);
                String detail = type.isEmpty() ? "Business" : type;
                if (!phone.isEmpty()) detail += "  •  " + phone;
                TextView d = text(detail, 13, Color.GRAY, false); d.setPadding(0, dp(4), 0, 0); card.addView(d);
                TextView totals = text("Sales: " + naira.format(database.getBusinessTotal(businessId, "SALE")) +
                        "    Expenses: " + naira.format(database.getBusinessTotal(businessId, "EXPENSE")), 12, NAVY, true);
                totals.setPadding(0, dp(10), 0, dp(8)); card.addView(totals);
                LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
                Button sale = button("+ RECORD SALE");
                Button expense = button("+ EXPENSE");
                Button inventory = button("INVENTORY");
                Button reports = button("BUSINESS REPORTS");
                LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(46), 1);
                actions.addView(sale, ap); LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(46), 1); ep.leftMargin = dp(8); actions.addView(expense, ep);
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(44)); ip.topMargin = dp(7); card.addView(inventory, ip);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(44)); rp.topMargin = dp(6); card.addView(reports, rp);
                inventory.setOnClickListener(v -> showInventory(businessId, name));
                reports.setOnClickListener(v -> showBusinessReports(businessId, name));
                sale.setOnClickListener(v -> showAddTransaction(businessId, name, "SALE"));
                expense.setOnClickListener(v -> showAddTransaction(businessId, name, "EXPENSE"));
                card.addView(actions);
                LinearLayout.LayoutParams cp = params(-1, -2); cp.topMargin = dp(9); content.addView(card, cp);
            }
        } finally { cursor.close(); }
        section("DATA & BACKUP");
        Button backup = button("SAVE BACKUP FILE");
        backup.setOnClickListener(v -> chooseBackupDestination());
        content.addView(backup, params(-1, dp(46)));
        Button restore = button("RESTORE FROM BACKUP");
        LinearLayout.LayoutParams restoreParams = params(-1, dp(46)); restoreParams.topMargin = dp(7);
        restore.setOnClickListener(v -> confirmRestore()); content.addView(restore, restoreParams);
        Button csv = button("EXPORT BUSINESS RECORDS (CSV)");
        LinearLayout.LayoutParams csvParams = params(-1, dp(46)); csvParams.topMargin = dp(7);
        csv.setOnClickListener(v -> chooseCsvDestination()); content.addView(csv, csvParams);

        TextView footer = text("OFFLINE-FIRST  •  DATA STORED ON THIS DEVICE", 10, Color.GRAY, true);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(26), 0, 0); content.addView(footer);
    }


    private void chooseBackupDestination() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, "MarvelBusinessManager-Backup-" + dateStamp() + ".mbak");
        startActivityForResult(intent, REQUEST_BACKUP);
    }

    private void confirmRestore() {
        new AlertDialog.Builder(this)
                .setTitle("Restore business data?")
                .setMessage("Choose a backup file created by MARVEL Business Manager. Restoring replaces the data currently stored in this app. Save a fresh backup first if you need to keep the current records.")
                .setNegativeButton("CANCEL", (d, w) -> d.dismiss())
                .setPositiveButton("CHOOSE BACKUP", (d, w) -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(intent, REQUEST_RESTORE);
                }).show();
    }

    private void chooseCsvDestination() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "MarvelBusinessManager-Records-" + dateStamp() + ".csv");
        startActivityForResult(intent, REQUEST_CSV);
    }

    private String dateStamp() {
        return new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQUEST_BACKUP) {
                exportDatabaseBackup(uri);
                Toast.makeText(this, "Backup file saved", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQUEST_RESTORE) {
                restoreDatabaseBackup(uri);
                Toast.makeText(this, "Backup restored successfully", Toast.LENGTH_LONG).show();
                render();
            } else if (requestCode == REQUEST_CSV) {
                exportCsv(uri);
                Toast.makeText(this, "CSV export saved", Toast.LENGTH_LONG).show();
            }
        } catch (Exception ex) {
            Toast.makeText(this, "Could not complete: " + safeMessage(ex), Toast.LENGTH_LONG).show();
        }
    }

    private String safeMessage(Exception ex) {
        String message = ex.getMessage();
        return message == null || message.trim().isEmpty() ? "please check the selected file and try again" : message;
    }

    private void exportDatabaseBackup(Uri destination) throws IOException {
        // Flush SQLite's write-ahead log before copying the database file.
        try (Cursor checkpoint = database.getWritableDatabase().rawQuery("PRAGMA wal_checkpoint(FULL)", null)) {
            if (checkpoint.moveToFirst() && checkpoint.getInt(0) != 0)
                throw new IOException("Database is busy; please try again");
        }
        database.close();
        File source = getDatabasePath("marvel_business_manager.db");
        if (!source.exists()) throw new IOException("No business database exists yet");
        try (InputStream in = new FileInputStream(source);
             OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
            if (out == null) throw new IOException("Could not open the selected destination");
            copy(in, out);
        } finally {
            database = new DatabaseHelper(this);
        }
    }

    private void restoreDatabaseBackup(Uri sourceUri) throws IOException {
        File incoming = new File(getCacheDir(), "restore-validation.tmp");
        File replacement = new File(getDatabasePath("marvel_business_manager.db").getParentFile(), "restore-ready.tmp");
        try (InputStream in = getContentResolver().openInputStream(sourceUri);
             OutputStream out = new FileOutputStream(incoming)) {
            if (in == null) throw new IOException("Could not read the selected backup");
            copy(in, out);
        }
        validateBackup(incoming);
        // Stage a complete replacement before closing the active database.
        try (InputStream in = new FileInputStream(incoming); OutputStream out = new FileOutputStream(replacement)) {
            copy(in, out);
        }
        database.close();
        File live = getDatabasePath("marvel_business_manager.db");
        new File(live.getPath() + "-wal").delete();
        new File(live.getPath() + "-shm").delete();
        if (live.exists() && !live.delete()) throw new IOException("Could not replace the current database");
        if (!replacement.renameTo(live)) {
            // Try to put the original staged bytes in place if rename is unsupported.
            try (InputStream in = new FileInputStream(incoming); OutputStream out = new FileOutputStream(live)) { copy(in, out); }
        }
        incoming.delete(); replacement.delete();
        database = new DatabaseHelper(this);
        database.getReadableDatabase();
    }

    private void validateBackup(File file) throws IOException {
        SQLiteDatabase check = null;
        try {
            check = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            try (Cursor integrity = check.rawQuery("PRAGMA integrity_check", null)) {
                if (!integrity.moveToFirst() || !"ok".equalsIgnoreCase(integrity.getString(0)))
                    throw new IOException("The selected database failed its integrity check");
            }
            String[] required = {"businesses", "products", "transactions", "stock_movements"};
            for (String table : required) {
                try (Cursor c = check.rawQuery("SELECT 1 FROM " + table + " LIMIT 0", null)) { /* table exists */ }
                catch (SQLiteException ex) { throw new IOException("This file is not a supported MARVEL backup"); }
            }
            try (Cursor version = check.rawQuery("PRAGMA user_version", null)) {
                if (version.moveToFirst() && version.getInt(0) > 2)
                    throw new IOException("This backup was created by a newer app version");
            }
        } catch (SQLiteException ex) {
            throw new IOException("The selected file is not a valid MARVEL database backup");
        } finally { if (check != null) check.close(); }
    }

    private void exportCsv(Uri destination) throws IOException {
        try (OutputStream stream = getContentResolver().openOutputStream(destination, "w")) {
            if (stream == null) throw new IOException("Could not open the selected destination");
            OutputStreamWriter writer = new OutputStreamWriter(stream, StandardCharsets.UTF_8);
            writer.write("record_type,business_id,business_name,record_id,item_or_type,quantity,cost_price,selling_price,amount,note_or_reason,created_at\r\n");
            appendCsvRows(writer, "SELECT id,name,business_type,phone,created_at FROM businesses ORDER BY id", "BUSINESS");
            appendCsvRows(writer, "SELECT p.id,p.business_id,b.name,p.name,p.quantity,p.cost_price,p.selling_price FROM products p JOIN businesses b ON b.id=p.business_id ORDER BY p.id", "PRODUCT");
            appendCsvRows(writer, "SELECT t.id,t.business_id,b.name,t.type,t.amount,t.note,t.created_at FROM transactions t JOIN businesses b ON b.id=t.business_id ORDER BY t.created_at,t.id", "TRANSACTION");
            appendCsvRows(writer, "SELECT m.id,p.business_id,b.name,p.name,m.change_amount,m.reason,m.created_at FROM stock_movements m JOIN products p ON p.id=m.product_id JOIN businesses b ON b.id=p.business_id ORDER BY m.created_at,m.id", "STOCK_MOVEMENT");
            writer.flush();
        }
    }

    private void appendCsvRows(OutputStreamWriter writer, String sql, String kind) throws IOException {
        try (Cursor c = database.getReadableDatabase().rawQuery(sql, null)) {
            while (c.moveToNext()) {
                String[] cells;
                if ("BUSINESS".equals(kind)) {
                    cells = new String[]{kind, c.getString(0), c.getString(1), c.getString(2), "", "", "", "", "", "Type: " + c.getString(2) + "; Phone: " + c.getString(3), formatTimestamp(c.getLong(4))};
                } else if ("PRODUCT".equals(kind)) {
                    cells = new String[]{kind, c.getString(1), c.getString(2), c.getString(0), c.getString(3), c.getString(4), c.getString(5), c.getString(6), "", "", ""};
                } else if ("TRANSACTION".equals(kind)) {
                    cells = new String[]{kind, c.getString(1), c.getString(2), c.getString(0), c.getString(3), "", "", "", c.getString(4), c.getString(5), formatTimestamp(c.getLong(6))};
                } else {
                    cells = new String[]{kind, c.getString(1), c.getString(2), c.getString(0), c.getString(3), c.getString(4), "", "", "", c.getString(5), formatTimestamp(c.getLong(6))};
                }
                for (int i = 0; i < cells.length; i++) {
                    if (i > 0) writer.write(",");
                    writer.write(csvCell(cells[i]));
                }
                writer.write("\r\n");
            }
        }
    }

    private String formatTimestamp(long millis) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date(millis));
    }

    private String csvCell(String value) {
        String safe = value == null ? "" : value;
        boolean numeric = false;
        if (!safe.isEmpty()) {
            try { Double.parseDouble(safe); numeric = true; } catch (NumberFormatException ignored) { }
        }
        if (!numeric && !safe.isEmpty() && "=+-@".indexOf(safe.charAt(0)) >= 0) safe = "'" + safe;
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }

    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192]; int count;
        while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        out.flush();
    }

    private void showAddTransaction(long businessId, String businessName, String type) {
        LinearLayout form = new LinearLayout(this);
        form.setPadding(dp(4), dp(8), dp(4), 0);
        form.setOrientation(LinearLayout.VERTICAL);
        EditText amount = field("Amount in Naira (₦) *", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText note = field(type.equals("SALE") ? "Sale description (optional)" : "Expense description *", InputType.TYPE_CLASS_TEXT);
        form.addView(amount); form.addView(note);
        String title = type.equals("SALE") ? "Record sale — " : "Record expense — ";
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title + businessName).setView(form)
                .setNegativeButton("CANCEL", (d, w) -> d.dismiss())
                .setPositiveButton("SAVE", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw = amount.getText().toString().trim();
            String description = note.getText().toString().trim();
            double value;
            try { value = Double.parseDouble(raw); } catch (NumberFormatException ex) { value = 0d; }
            if (value <= 0d) { amount.setError("Enter an amount greater than zero"); return; }
            if (type.equals("EXPENSE") && description.isEmpty()) { note.setError("Describe this expense"); return; }
            long id = database.addTransaction(businessId, type, value, description);
            if (id > 0) { Toast.makeText(this, type.equals("SALE") ? "Sale saved" : "Expense saved", Toast.LENGTH_SHORT).show(); dialog.dismiss(); render(); }
            else Toast.makeText(this, "Could not save this record", Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }



    private void showBusinessReports(long businessId, String businessName) {
        long now = System.currentTimeMillis();
        long thirtyDaysAgo = now - 30L * 24L * 60L * 60L * 1000L;
        double allSales = database.getBusinessTotal(businessId, "SALE");
        double allExpenses = database.getBusinessTotal(businessId, "EXPENSE");
        double recentSales = database.getBusinessTotalSince(businessId, "SALE", thirtyDaysAgo);
        double recentExpenses = database.getBusinessTotalSince(businessId, "EXPENSE", thirtyDaysAgo);
        double costValue = database.getInventoryCostValue(businessId);
        double retailValue = database.getInventorySellingValue(businessId);
        double net = allSales - allExpenses;
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(5), dp(8), dp(5), dp(4));
        panel.addView(text("LIFETIME PERFORMANCE", 11, Color.GRAY, true));
        panel.addView(reportLine("Total sales", naira.format(allSales), NAVY));
        panel.addView(reportLine("Total expenses", naira.format(allExpenses), Color.rgb(170,70,55)));
        panel.addView(reportLine("Net cash result*", naira.format(net), net >= 0 ? Color.rgb(35,130,85) : Color.rgb(180,65,55)));
        TextView note = text("*Sales minus recorded expenses. This is not a full accounting profit calculation because product purchase costs are not automatically posted as expenses.", 11, Color.GRAY, false);
        note.setPadding(0, dp(6), 0, dp(14)); panel.addView(note);
        panel.addView(text("LAST 30 DAYS", 11, Color.GRAY, true));
        panel.addView(reportLine("Sales", naira.format(recentSales), NAVY));
        panel.addView(reportLine("Expenses", naira.format(recentExpenses), NAVY));
        panel.addView(reportLine("Net result", naira.format(recentSales - recentExpenses), recentSales >= recentExpenses ? Color.rgb(35,130,85) : Color.rgb(180,65,55)));
        TextView inventoryTitle = text("INVENTORY VALUE", 11, Color.GRAY, true); inventoryTitle.setPadding(0, dp(14), 0, 0); panel.addView(inventoryTitle);
        panel.addView(reportLine("Products", String.valueOf(database.getProductCount(businessId)), NAVY));
        panel.addView(reportLine("Stock at cost value", naira.format(costValue), NAVY));
        panel.addView(reportLine("Stock at selling value", naira.format(retailValue), NAVY));
        panel.addView(reportLine("Potential margin on current stock", naira.format(retailValue - costValue), NAVY));
        panel.addView(reportLine("Low-stock items", String.valueOf(database.getLowStockCount(businessId)), Color.rgb(180,90,35)));
        new AlertDialog.Builder(this).setTitle(businessName + " — Reports").setView(panel)
                .setPositiveButton("CLOSE", (d, w) -> d.dismiss()).show();
    }

    private LinearLayout reportLine(String label, String value, int valueColor) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(7), 0, dp(7));
        TextView left = text(label, 13, Color.DKGRAY, false);
        TextView right = text(value, 13, valueColor, true); right.setGravity(Gravity.RIGHT);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1)); row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        // Return a compact wrapper so report rows remain vertically spaced.
        LinearLayout wrapper = new LinearLayout(this); wrapper.setOrientation(LinearLayout.VERTICAL); wrapper.addView(row);
        View divider = new View(this); divider.setBackgroundColor(Color.rgb(232,235,239)); wrapper.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        return wrapper;
    }

    private void showInventory(long businessId, String businessName) {
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(4), dp(6), dp(4), 0);
        TextView info = text("Products, quantities and low-stock alerts", 13, Color.GRAY, false);
        info.setPadding(0, 0, 0, dp(8)); panel.addView(info);
        Button add = button("+ ADD PRODUCT"); panel.addView(add, params(-1, dp(46)));
        Cursor products = database.getProducts(businessId);
        try {
            if (!products.moveToFirst()) {
                TextView empty = text("No products yet. Add your first product.", 14, NAVY, false);
                empty.setPadding(0, dp(12), 0, dp(8)); panel.addView(empty);
            } else do {
                long productId = products.getLong(0); String productName = products.getString(1);
                double qty = products.getDouble(2), cost = products.getDouble(3), price = products.getDouble(4), threshold = products.getDouble(5);
                LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
                item.setPadding(dp(10), dp(9), dp(10), dp(9)); item.setBackgroundColor(Color.rgb(245,247,250));
                item.addView(text(productName, 15, NAVY, true));
                String stockLine = "Stock: " + qty + "  •  Cost: " + naira.format(cost) + "  •  Sell: " + naira.format(price);
                item.addView(text(stockLine, 12, Color.DKGRAY, false));
                if (qty <= threshold) item.addView(text("LOW STOCK — threshold: " + threshold, 12, Color.rgb(180,70,35), true));
                LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
                Button sell = button("SELL"); Button adjust = button("ADJUST STOCK");
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(42), 1); actions.addView(sell, bp);
                LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(0, dp(42), 1); bp2.leftMargin = dp(7); actions.addView(adjust, bp2);
                item.addView(actions); sell.setOnClickListener(v -> showProductSale(businessId, productId, productName, qty));
                adjust.setOnClickListener(v -> showStockAdjustment(productId, productName));
                LinearLayout.LayoutParams itemParams = params(-1, -2); itemParams.topMargin = dp(7); panel.addView(item, itemParams);
            } while (products.moveToNext());
        } finally { products.close(); }
        AlertDialog inventoryDialog = new AlertDialog.Builder(this).setTitle(businessName + " — Inventory").setView(panel)
                .setPositiveButton("CLOSE", (d,w) -> { d.dismiss(); render(); }).create();
        add.setOnClickListener(v -> { inventoryDialog.dismiss(); showAddProduct(businessId, businessName); });
        inventoryDialog.show();
    }

    private void showAddProduct(long businessId, String businessName) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(4), dp(8), dp(4), 0);
        EditText name = field("Product name *", InputType.TYPE_CLASS_TEXT);
        EditText qty = field("Opening quantity *", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText cost = field("Cost price per unit (₦)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText price = field("Selling price per unit (₦)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText threshold = field("Low-stock alert level (default 5)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(name); form.addView(qty); form.addView(cost); form.addView(price); form.addView(threshold);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Add product — " + businessName).setView(form)
                .setNegativeButton("CANCEL", (d,w) -> d.dismiss()).setPositiveButton("SAVE", null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim(); double q = number(qty), c = number(cost), sp = number(price);
            double low = threshold.getText().toString().trim().isEmpty() ? 5 : number(threshold);
            if (n.isEmpty()) { name.setError("Product name is required"); return; }
            if (qty.getText().toString().trim().isEmpty() || q < 0 || c < 0 || sp <= 0 || low < 0) {
                price.setError("Enter valid quantity, cost, selling price and alert level"); return;
            }
            if (database.addProduct(businessId, n, q, c, sp, low) > 0) {
                Toast.makeText(this, "Product saved", Toast.LENGTH_SHORT).show(); dialog.dismiss(); render();
            } else Toast.makeText(this, "Could not save product", Toast.LENGTH_SHORT).show();
        })); dialog.show();
    }

    private void showProductSale(long businessId, long productId, String productName, double available) {
        EditText quantity = field("Quantity to sell (available: " + available + ")", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Sell " + productName).setView(quantity)
                .setNegativeButton("CANCEL", (d,w) -> d.dismiss()).setPositiveButton("RECORD SALE", null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double q = number(quantity); if (q <= 0) { quantity.setError("Enter a quantity greater than zero"); return; }
            if (!database.sellProduct(businessId, productId, q)) { quantity.setError("Not enough stock or sale could not be saved"); return; }
            Toast.makeText(this, "Sale saved and stock deducted", Toast.LENGTH_SHORT).show(); dialog.dismiss(); render();
        })); dialog.show();
    }

    private void showStockAdjustment(long productId, String productName) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        EditText change = field("Quantity change (+ add, - remove)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText reason = field("Reason (e.g. new delivery, damaged)", InputType.TYPE_CLASS_TEXT);
        form.addView(change); form.addView(reason);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Adjust " + productName).setView(form)
                .setNegativeButton("CANCEL", (d,w) -> d.dismiss()).setPositiveButton("SAVE", null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            double delta; try { delta = Double.parseDouble(change.getText().toString().trim()); } catch (Exception ex) { delta = 0; }
            if (delta == 0) { change.setError("Enter a non-zero quantity change"); return; }
            if (!database.adjustStock(productId, delta, reason.getText().toString())) { change.setError("Invalid adjustment; stock cannot become negative"); return; }
            dialog.dismiss(); render(); Toast.makeText(this, "Stock updated", Toast.LENGTH_SHORT).show();
        })); dialog.show();
    }

    private double number(EditText field) { try { return Double.parseDouble(field.getText().toString().trim()); } catch (Exception ex) { return 0d; } }

    private void showAddBusiness() {
        LinearLayout form = new LinearLayout(this); form.setPadding(dp(4), dp(8), dp(4), 0); form.setOrientation(LinearLayout.VERTICAL);
        EditText name = field("Business name *", InputType.TYPE_CLASS_TEXT);
        EditText type = field("Business type (optional)", InputType.TYPE_CLASS_TEXT);
        EditText phone = field("Phone number (optional)", InputType.TYPE_CLASS_PHONE);
        form.addView(name); form.addView(type); form.addView(phone);
        new AlertDialog.Builder(this).setTitle("Add a business").setView(form)
                .setNegativeButton("CANCEL", (d, w) -> d.dismiss())
                .setPositiveButton("SAVE", (d, w) -> {
                    String businessName = name.getText().toString().trim();
                    if (businessName.isEmpty()) { name.setError("Business name is required"); return; }
                    long id = database.addBusiness(businessName, type.getText().toString(), phone.getText().toString());
                    if (id > 0) render();
                }).show();
    }

    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setInputType(inputType);
        e.setTextSize(15); e.setPadding(dp(10), dp(8), dp(10), dp(8)); return e;
    }
    private LinearLayout statCard(String label, String value) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12), dp(12), dp(8), dp(8)); box.setBackgroundColor(Color.WHITE);
        box.addView(text(label, 10, Color.GRAY, true)); TextView v = text(value, 17, NAVY, true); v.setPadding(0, dp(7), 0, 0); box.addView(v); return box;
    }
    private void section(String s) { TextView t = text(s, 11, Color.GRAY, true); t.setPadding(0, dp(22), 0, dp(10)); content.addView(t); }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextColor(NAVY); b.setTextSize(13); b.setTypeface(null, Typeface.BOLD); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD)); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD); return t; }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    @Override protected void onDestroy() { super.onDestroy(); if (database != null) database.close(); }
}
